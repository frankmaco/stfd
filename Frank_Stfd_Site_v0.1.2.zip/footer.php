
</div><!--	End Container-->



<footer>
<p>Stfd Creative  info@stfdcreative.com</p>
  <div id = "bottom_nav">
  <ul>
      <li><a href="about.html">About</a></li>
      <li><a href="events.html">Events</a></li>
      <li><a href="message_board.html">Message Board</a></li>
      <li><a href="gallery.html">Gallery</a></li>
      <li><a href="contact.html">Contact</a></li>
  </ul>
  </div>
</footer>

</div><!--	End Wrapper-->
</body>
</html>
