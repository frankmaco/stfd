<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Stfd Creative</title>
  <link rel="stylesheet" href="css/main.css">

  <body>
  <div id ="wrapper">
    <h1><a href="index.html">Stratford Creative</a></h1>

      <nav>
        <ul>
          <li><a href="about.html">About</a></li>
          <li class="link_spacing"><a href="events.html">Events</a></li>
          <li class="link_spacing"><a href="message_board.html">Message Board</a></li>
          <li class="link_spacing"><a href="gallery.html">Gallery</a></li>
          <li class="link_spacing"><a href="contact.php">Contact</a></li>
        </ul>
      </nav>

    <div id = "container">
