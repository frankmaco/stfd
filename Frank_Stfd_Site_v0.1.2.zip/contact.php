<?php include 'header.php'; ?>
			<h2>Contact</h2>
	<form method= "get" action= "mailto:example@example.com">
          <div>
          	<label for="name">Name</label><br>
          	<input type="text" name="name" id="name"/>
          </div>

          <div>
          	<label for="email">Email</label><br>
          	<input type="text" name="phone" id="phone"/>
          </div>

           <div>
          	<label for="message">Message</label><br>
          	<textarea rows="12" cols="50" name="mesage" id="message"></textarea>
          </div>
          <div>
          	<button type="submit" name="submit" class="button">Send Message</button>
          </div>

   </form>
	<?php include 'footer.php'; ?>
